#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
GRADLE_VERSION=8.9
mkdir -p .gradle-local
if [ ! -x ".gradle-local/gradle-$GRADLE_VERSION/bin/gradle" ]; then
  curl -L "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o .gradle-local/gradle.zip
  unzip -oq .gradle-local/gradle.zip -d .gradle-local
fi
if [ -z "${ANDROID_HOME:-}" ] && [ -d "$HOME/Android/Sdk" ]; then export ANDROID_HOME="$HOME/Android/Sdk"; fi
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [ -z "$ANDROID_SDK_ROOT" ]; then echo "Android SDK not found. Install Android Studio and Android SDK Platform 35 first."; exit 1; fi
.gradle-local/gradle-$GRADLE_VERSION/bin/gradle assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"

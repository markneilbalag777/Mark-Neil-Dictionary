@echo off
setlocal
cd /d "%~dp0"
set GRADLE_VERSION=8.9
set GRADLE_HOME=%CD%\.gradle-local\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  if not exist ".gradle-local" mkdir .gradle-local
  echo Downloading Gradle %GRADLE_VERSION% for the first build...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '.gradle-local\gradle.zip'; Expand-Archive -Path '.gradle-local\gradle.zip' -DestinationPath '.gradle-local' -Force"
  if errorlevel 1 (echo Gradle download failed. Install Gradle 8.9 manually and try again. & pause & exit /b 1)
)
if "%ANDROID_HOME%"=="" if exist "%LOCALAPPDATA%\Android\Sdk" set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk
if "%ANDROID_SDK_ROOT%"=="" if not "%ANDROID_HOME%"=="" set ANDROID_SDK_ROOT=%ANDROID_HOME%
if "%ANDROID_HOME%"=="" (echo Android SDK not found. Install Android Studio and Android SDK Platform 35 first. & pause & exit /b 1)
call "%GRADLE_HOME%\bin\gradle.bat" assembleDebug
if errorlevel 1 (echo Build failed. Check the Gradle error above. & pause & exit /b 1)
echo.
echo APK created at: app\build\outputs\apk\debug\app-debug.apk
pause

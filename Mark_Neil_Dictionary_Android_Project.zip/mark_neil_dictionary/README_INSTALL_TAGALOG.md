# TALA Offline Dictionary — Android project

This is an offline-first Android WebView app with a bundled local vocabulary database. The app manifest intentionally has **no INTERNET permission**. Dictionary lookups, verb forms, phrasebook translations and the English spelling index are stored in the app.

## What is included

- Tagalog ↔ English starter dictionary (425 curated bilingual entries).
- Large English spelling index (124,058 spellings) from the CMU Pronouncing Dictionary package. This index confirms spellings, but most rare words do not yet have a Tagalog translation in the starter bilingual dataset.
- Australian English equivalents and labels where a common Aussie expression exists.
- Verb tense helper with irregular verb forms and regular-verb rules.
- Two-way phrase translation: Tagalog → Natural English / Australian English; Normal English or Australian English → Tagalog.
- Android on-device speech recognition request and Android Text-to-Speech bridge.
- Saved words stored locally on the device.

## Important offline limitations

1. Speech recognition uses Android's on-device recognizer (`createOnDeviceSpeechRecognizer`). It works only if the phone supports it and has the required offline language pack. Filipino (`fil-PH`) and English (`en-US` / `en-AU`) support varies by device and Android speech service.
2. Text-to-speech uses installed Android voice data. Install Filipino and Australian English voice data if available.
3. The sentence translator is a local phrasebook + word-by-word fallback, not a full AI grammar engine. Unfamiliar or complex sentences may need correction.
4. The English spelling index is large but not literally every English word; it includes names, variants and uncommon forms from CMUdict. A spelling match does not guarantee a Tagalog definition.

## Build an APK in Android Studio

Requirements: a Windows, macOS or Linux computer, Android Studio, and an internet connection for the first Gradle/Android SDK setup. The app itself has no Internet permission and is designed to run offline after installation.

1. Extract the ZIP file.
2. Open Android Studio → **Open** → select the extracted `Mark-Neil-Dictionary` project folder.
3. Allow Android Studio to install the requested Android SDK (API 35) and sync Gradle. This first build setup requires internet.
4. Connect an Android phone or use Build → Build Bundle(s) / APK(s) → **Build APK(s)**. You can also run `BUILD_APK_WINDOWS.bat` on Windows after Android Studio and SDK Platform 35 are installed.
5. When the build completes, choose **locate**. The APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy `app-debug.apk` to your phone. Tap it in Files. If prompted, allow **Install unknown apps** for the Files app, then tap Install.

## Set up offline speech on the phone

Android settings differ by manufacturer. Look for Settings → System / General management → Language & input → Voice input / Speech recognition → Offline speech recognition, then download Filipino and English packs if offered. For spoken output, open Text-to-speech settings → install voice data and look for Filipino and English (Australia).

If Filipino offline recognition is not offered by the phone, the dictionary still works offline; use the text box for translation.

## Run the web preview

Open `app/src/main/assets/www/index.html` in a browser to preview the interface. The Android APK is the intended package for native offline microphone and voice output.

## Data attribution

The English spelling index is generated from the installed `cmudict` Python package, which distributes the Carnegie Mellon Pronouncing Dictionary. Consult the package's included licence/attribution when redistributing the data. The Tagalog/English vocabulary and phrase examples in this starter set are manually curated for this project.

## Licence notice

The bundled CMU-derived English spelling index is under GPL-3.0-or-later according to the `cmudict` package metadata. The full licence text is included as `LICENSE_GPL-3.0.txt`; read `THIRD_PARTY_NOTICES.md` before redistributing the app.

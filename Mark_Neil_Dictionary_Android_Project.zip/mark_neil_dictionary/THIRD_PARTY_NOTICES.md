# Third-party notices

## CMU Pronouncing Dictionary / cmudict

The bundled English spelling index was generated from the `cmudict` Python package, version 1.1.3, which distributes data from the Carnegie Mellon Pronouncing Dictionary. The package metadata identifies the licence as **GPL-3.0-or-later**. The complete GPL-3.0 text is included in `LICENSE_GPL-3.0.txt`.

The index in this app is a spelling index only. It does not include full dictionary definitions or Tagalog translations for every entry. Redistribution of this project and its bundled CMU-derived data must comply with the GPL terms.

## Project-specific content

The Tagalog-English vocabulary and phrase examples in `dictionary-data.js` were manually curated for this starter project. Australian expressions are labelled or described as informal where appropriate; not every English word has a distinct Australian equivalent.

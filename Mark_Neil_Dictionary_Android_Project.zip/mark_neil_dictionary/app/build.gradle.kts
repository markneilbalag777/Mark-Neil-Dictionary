plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tala.offlinedictionary"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tala.offlinedictionary"
        minSdk = 31
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
}

package com.tala.offlinedictionary

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var webView: WebView
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var pendingLanguage = "fil-PH"
    private var ttsReady = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(NativeBridge(), "Android")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/www/index.html")
    }

    inner class NativeBridge {
        @JavascriptInterface fun startListening(languageTag: String) {
            runOnUiThread {
                pendingLanguage = languageTag
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1001)
                } else startOnDeviceRecognition(languageTag)
            }
        }
        @JavascriptInterface fun speak(text: String, languageTag: String) {
            runOnUiThread {
                if (!ttsReady) { sendToJs("", "Text-to-speech is still starting. Try again."); return@runOnUiThread }
                val locale = Locale.forLanguageTag(languageTag)
                val availability = tts?.isLanguageAvailable(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (availability < TextToSpeech.LANG_AVAILABLE) {
                    sendToJs("", "This phone does not have the $languageTag voice installed. Download its offline voice data in Text-to-speech settings.")
                    return@runOnUiThread
                }
                tts?.language = locale
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tala-voice")
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startOnDeviceRecognition(pendingLanguage)
            else sendToJs("", "Microphone permission was not granted.")
        }
    }

    private fun startOnDeviceRecognition(languageTag: String) {
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            sendToJs("", "On-device speech recognition is not available on this phone. Install an offline speech pack or type the sentence instead.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { }
            override fun onBeginningOfSpeech() { }
            override fun onRmsChanged(rmsdB: Float) { }
            override fun onBufferReceived(buffer: ByteArray?) { }
            override fun onEndOfSpeech() { }
            override fun onError(error: Int) { sendToJs("", "Speech recognition error ($error). Check that the offline language pack is installed.") }
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isBlank()) sendToJs("", "No speech was recognised. Try again or type your sentence.") else sendToJs(text, "")
            }
            override fun onPartialResults(partialResults: Bundle?) { }
            override fun onEvent(eventType: Int, params: Bundle?) { }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun sendToJs(text: String, error: String) {
        val safeText = org.json.JSONObject.quote(text)
        val safeError = org.json.JSONObject.quote(error)
        runOnUiThread { webView.evaluateJavascript("window.onNativeSpeechResult($safeText, $safeError)", null) }
    }

    override fun onInit(status: Int) { ttsReady = status == TextToSpeech.SUCCESS }
    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        webView.destroy()
        super.onDestroy()
    }
}
